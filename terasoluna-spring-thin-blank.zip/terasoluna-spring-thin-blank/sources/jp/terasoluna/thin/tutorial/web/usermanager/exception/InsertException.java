package jp.terasoluna.thin.tutorial.web.usermanager.exception;

/**
 * 業務例外クラス。
 *
 */
public class InsertException extends RuntimeException {

    /**
     * シリアルバージョンID。
     */
    private static final long serialVersionUID = 1L;

}