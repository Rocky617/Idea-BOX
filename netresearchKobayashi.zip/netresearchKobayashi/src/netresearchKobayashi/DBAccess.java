package netresearchKobayashi;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBAccess {

	protected void inputInfo(PhotoBean photobn) throws Exception {
		Connection con = null;
		PreparedStatement stmt = null;

		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/netresearchKobayashi", "root", "");
			con.setAutoCommit(false);
			stmt = con.prepareStatement("INSERT INTO image (image, title, location, posted_date, update_date) VALUES(?, ?, ?, CURRENT_DATE, NOW())");

			stmt.setString(1, photobn.getPhoto());
			stmt.setString(2, photobn.getTitle());
			stmt.setString(3, photobn.getLocation());
			stmt.executeUpdate();

			ResultSet posting = null;
			posting = stmt.executeQuery("SELECT posted_date FROM image");
			con.commit();

		}catch(Exception e) {
			e.printStackTrace();
			if(con != null) {
				con.rollback();
			}
		}finally{
			if(stmt != null) {
				stmt.close();
			}
			if(con != null) {
				con.close();
			}
		}
	}

	public Blob toppagePhoto() {

		String photo = null;

		Connection con = null;
		Statement stmt = null;

		String ret = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/netresearchKobayashi", "root", "");
			stmt = con.createStatement();

			ResultSet rset = stmt.executeQuery("SELECT image FROM image order by 'image_id' limit 4");
			while (rset.next()) {
			 ret = rset.getString("rset");
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}

		return ret;
	}


	public void imageinfo(PhotoBean photoBn) {

		Connection con = null;
		Statement stmt = null;

		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/netresearchKobayashi", "root", "");
			stmt = con.createStatement();

			String image = photoBn.getPhoto() + ".jpg";
			ResultSet rset = stmt.executeQuery("select image, title, location, posted_date from image where image = '"+image+"'");

			while (rset.next()) {
				photoBn.setPhoto(rset.getString(1));
				photoBn.setTitle(rset.getString(2));
				photoBn.setLocation(rset.getString(3));
				photoBn.setPostedDate(rset.getString(4));
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
