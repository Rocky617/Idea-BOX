package netresearchKobayashi;

import java.io.Serializable;

public class PhotoBean implements Serializable {
	private String photo;
	private String title;
	private String location;
	private String postedDate;

	public  PhotoBean() {
		photo = "";
		title = "";
		location = "";
		postedDate = "";
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

}
