package netresearchKobayashi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Upload extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {

	HttpSession session = request.getSession();

	String photo = request.getParameter("photo");
	String title = request.getParameter("title");
	String location = request.getParameter("location");
	List<String> errorList = new ArrayList<String>();

	String path = "";

	if(request.getParameter("top") != null) {
		path = "/JSP/top.jsp";
	}else{
		if(photo == null || photo.equals("")) {
			errorList.add("アップロードする写真を選んでください");
//		画像ファイル判定、すべてはじいてしまい機能していないので要修正
//		}else if(photo.endsWith(".jpg") == false || photo.endsWith(".png") == false) {
//			errorList.add("選択できるのは画像ファイルのみです");
		}

		if(!title.equals("無題")) {
			if(title.length() > 40) {
				errorList.add("タイトルは40文字まで入力してください");
			}
		}
		if(!location.equals("")) {
			if(location.length() > 40) {
				errorList.add("撮影場所は40文字までで入力してください");
			}
		}
		PhotoBean bn = new PhotoBean();

		bn.setPhoto(photo);
		bn.setTitle(title);
		bn.setLocation(location);

		session.setAttribute("bn", bn);

		path = "/JSP/conf.jsp";

		if(!errorList.isEmpty()) {
			path="/JSP/upload.jsp";
			request.setAttribute("errorList", errorList);
		}
	}

	RequestDispatcher rd = request.getRequestDispatcher(path);
	rd.forward(request, response);

	}
}
