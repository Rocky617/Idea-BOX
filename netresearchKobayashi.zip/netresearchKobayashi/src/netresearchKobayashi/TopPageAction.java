package netresearchKobayashi;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class TopPageAction extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	HttpSession session = request.getSession();
	String path = "";

	if(request.getParameter("upload") != null) {
		path = "/JSP/upload.jsp";

	}else if(request.getParameter("link") != null) {
		PhotoBean bn = new PhotoBean();
		String image = request.getParameter("link");
		bn.setPhoto(image);
		DBAccess DBac = new DBAccess();

		DBac.imageinfo(bn);

		session.setAttribute("bn", bn);

		path = "/JSP/photoPage.jsp";
	}else if(request.getParameter("photoPage") != null) {
		path = "/JSP/photoPage.jsp";
	}
	RequestDispatcher rd = request.getRequestDispatcher(path);
	rd.forward(request, response);

	}
}
