package netresearchKobayashi;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ConfAction extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {

		HttpSession session = request.getSession();
		PhotoBean bn = (PhotoBean)session.getAttribute("bn");

		String path = "";
		if(request.getParameter("back") != null) {
			path = "/JSP/upload.jsp";
		}else{
			try{
				DBAccess DB = new DBAccess();
				DB.inputInfo(bn);
			}catch (Exception e) {
				e.printStackTrace();
			}
			path = "/JSP/end.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(path);
		rd.forward(request, response);

	}
}
